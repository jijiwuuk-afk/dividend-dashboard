배당 대시보드 자동뉴스 버전

- `data/market_data.json` 자동 생성 (최근 1개월 차트용)
